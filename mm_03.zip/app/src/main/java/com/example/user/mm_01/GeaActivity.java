package com.example.user.mm_01;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class GeaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_gea);
        ArrayList<String> arraylist = new ArrayList<String>();
        arraylist.add("1");
        arraylist.add("2");
        arraylist.add("3");
        arraylist.add("4");
        arraylist.add("5");
        arraylist.add("6");
        arraylist.add("7");
        arraylist.add("8");


        ArrayAdapter<String> Adapter;
        Adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arraylist);

        ListView list = (ListView)findViewById(R.id.list);
        list.setAdapter(Adapter);  
    }
}
