package com.example.user.mm_01;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;


public class LoginActivity extends AppCompatActivity {

    TabHost tabHost;
    Button btn1, btn2, btn3, ok6, btnWrite, btn01, btn02, btn03,set,home;
    DatePicker dp;
    EditText edtDiary;
    String fileName;
    AudioManager am;
    ImageView waterImage1,waterImage3;
       ImageView skyImage;
    ImageView swingImage;

    Animation flowAnimation;
    Animation shakeAnimation;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        swingImage = (ImageView)findViewById(R.id.swingImage);
        shakeAnimation = AnimationUtils.loadAnimation(this,R.anim.shake);
        swingImage.setAnimation(shakeAnimation);

        skyImage = (ImageView)findViewById(R.id.skyImage);
        flowAnimation = AnimationUtils.loadAnimation(this,R.anim.flow);
        skyImage.setAnimation(flowAnimation);

        Resources res = getResources();
        Bitmap bitmap = BitmapFactory.decodeResource(res, R.drawable.sky_background);

        int bitmapWidth = bitmap.getWidth();
        int bitmapHeight = bitmap.getHeight();

        ViewGroup.LayoutParams params = skyImage.getLayoutParams();
        params.width = bitmapWidth;
        params.height =bitmapHeight;

        skyImage.setImageBitmap(bitmap);
        flowAnimation.setAnimationListener(new AnimationAdapter());

        tabHost = (TabHost) findViewById(R.id.tabHost);
        tabHost.setup();

        TabHost.TabSpec spec1 = tabHost.newTabSpec("Tab1")
                .setContent(R.id.linearLayout3).setIndicator("홈");
        tabHost.addTab(spec1);

        TabHost.TabSpec spec2 = tabHost.newTabSpec("Tab2")
                .setContent(R.id.linearLayout2).setIndicator("게시판");
        tabHost.addTab(spec2);

        TabHost.TabSpec spec3 = tabHost.newTabSpec("Tab3")
                .setContent(R.id.linearLayout1).setIndicator("지도");
        tabHost.addTab(spec3);

        TabHost.TabSpec spec4 = tabHost.newTabSpec("Tab4")
                .setContent(R.id.linearLayout4).setIndicator("달력");
        tabHost.addTab(spec4);

        tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabld) {
                if (tabld.equals("Tab1")) {

                } else if (tabld.equals("Tab2")) {

                } else if (tabld.equals("Tab3")) {

                } else if (tabld.equals("Tab4")) {

                }
            }
        });




        dp = (DatePicker) findViewById(R.id.datePic01);
        edtDiary = (EditText) findViewById(R.id.edtDiary);
        btnWrite = (Button) findViewById(R.id.btn445);

        Calendar cal = Calendar.getInstance();
        int cYear = cal.get(Calendar.YEAR);
        int cMonth = cal.get(Calendar.MONTH);
        int cDay = cal.get(Calendar.DAY_OF_MONTH);

        dp.init(cYear, cMonth, cDay, new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                fileName = Integer.toString(year) + "-"
                        + Integer.toString(monthOfYear) + "-"
                        + Integer.toString(dayOfMonth) + ".txt";
                String str = readDiary(fileName);
                edtDiary.setText(str);
                btnWrite.setEnabled(true);
            }

        });

        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    FileOutputStream outFs = openFileOutput(fileName,
                            Context.MODE_PRIVATE);
                    String str = edtDiary.getText().toString();
                    outFs.write(str.getBytes());
                    outFs.close();
                    Toast.makeText(getApplicationContext(), fileName + "이 저장됨",
                            Toast.LENGTH_SHORT).show();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


        Button btn03 = (Button) findViewById(R.id.goglemap);
        btn03.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(intent);
            }
        });




        ListView listView;
        ListViewAdapter adapter;


        //Adapter 생성
        adapter = new ListViewAdapter();

        //리스트뷰 참조 및 Adapter닫기
        listView = (ListView)findViewById(R.id.listview1);
        listView.setAdapter(adapter);

        //첫 번째 아이템 추가
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.nike),
                "Like", "22000원");
        //두번째
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.newbal),
                "NewBalance", "99000원");
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.newbal),
                "NewBalance", "99000원");
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.newbal),
                "NewBalance", "99000원");

        //위에서 생성한 ListView에 클릭 이벤트 핸들러 정의
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //get item
                ListViewItem item = (ListViewItem) parent.getItemAtPosition(position);

                String titleStr = item.getTitle();
                String descStr = item.getDesc();
                Drawable iconDrawable = item.getIcon();
            }
        });


    }



    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus){
            shakeAnimation.start();

            flowAnimation.start();
        }else {
            shakeAnimation.reset();

            flowAnimation.reset();

        }
    }

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }
    private  final  class AnimationAdapter implements Animation.AnimationListener{


        @Override
        public void onAnimationStart(Animation animation) {

        }

        @Override
        public void onAnimationEnd(Animation animation) {

        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    }

    String readDiary(String fName) {
        String diaryStr = null;
        FileInputStream inFs;
        try {
            inFs = openFileInput(fName);
            byte[] txt = new byte[500];
            inFs.read(txt);
            inFs.close();
            diaryStr = (new String(txt)).trim();
            btnWrite.setText("수정하기");
        } catch (IOException e) {
            edtDiary.setHint("일기 없음");
            btnWrite.setText("새로 저장");
        }
        return diaryStr;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.overflower_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.login) {
            Toast.makeText(getApplicationContext(), "로그인이 필요합니다.", Toast.LENGTH_SHORT).show();
            return true;
        }

        if (id == R.id.page_facebook) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.facebook.com"));
            startActivity(intent);
            return true;
        }

        if (id == R.id.page_naver) {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://nid.naver.com/nidlogin.login?svctype=262144&url=http://m.naver.com/aside/&url=http://m.naver.com/aside/"));
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
