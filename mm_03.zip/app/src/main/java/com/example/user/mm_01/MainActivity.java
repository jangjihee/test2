package com.example.user.mm_01;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.os.Build;
import android.os.PowerManager;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.BatchUpdateException;


public class MainActivity extends AppCompatActivity {
    AudioManager am;
    PowerManager.WakeLock wakeLock;
    PowerManager powerManager;
    Button home,set,login;
    EditText IdText,passwordText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Switch sw = (Switch)findViewById(R.id.jd);
        Switch sw2 = (Switch)findViewById(R.id.jjj);
        am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        wakeLock = null;
        powerManager = (PowerManager)getSystemService(POWER_SERVICE);


        sw2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @SuppressLint("InvalidWakeLockTag")
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true){
                    Intent batterySaverIntent=new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                    startActivity(batterySaverIntent);
                } else {
                    wakeLock = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "wakelock");
                    wakeLock.acquire();
                }
            }
        });




        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked == true){
                    am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
                } else {
                    am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                }
            }
        });

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());

        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        set = (Button)findViewById(R.id.set);

        set.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent intent = new Intent(Settings.ACTION_SETTINGS);

                startActivityForResult(intent, 0);



            }
        });


        Button btn02 = (Button) findViewById(R.id.registerButton);
        btn02.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });


        IdText = (EditText) findViewById(R.id.IdText);
        passwordText = (EditText) findViewById(R.id.passwordText);






        home.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), StartActivity.class);
                startActivity(intent);
            }
        });

        Button btn01 = (Button) findViewById(R.id.loginButton);
        btn01.setOnClickListener(new View.OnClickListener(){

        @Override
            public void onClick(View v) {
                // 보내는 메시지를 받아옴
                String sId = IdText.getText().toString();
                String sPass = passwordText.getText().toString();

                String msg = sId + "/" + sPass;

                // 메시지를 서버에 보냄
                String result = SendByHttp(msg);

                // JSON 데이터 파싱
                String parsedData = jsonParserList(result);

                Toast.makeText(getApplicationContext(), parsedData, Toast.LENGTH_SHORT).show();

                if (parsedData.equals("로그인성공")) {
                    Intent loginIntent = new Intent(getApplicationContext(), LoginActivity.class);
                    MainActivity.this.startActivity(loginIntent);
                } else {
                    Toast.makeText(getApplicationContext(), "아이디와 비번을 확인해주세요.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
}
        private String SendByHttp(String msg) {
            if (msg == null)
                msg = "";

            String URL = "http://데스크 탑 IP/" + "WEBSERVER.JSP";

            DefaultHttpClient client = new DefaultHttpClient();

            try {
                /* 체크할 id와 pwd값 서버로 전송 */
                HttpPost post = new HttpPost(URL + "?msg=" + msg);

                /* 지연시간 최대 5초 */
                HttpParams params = client.getParams();
                HttpConnectionParams.setConnectionTimeout(params, 3000);
                HttpConnectionParams.setSoTimeout(params, 3000);

                /* 데이터 보낸 뒤 서버에서 데이터를 받아오는 과정 */
                HttpResponse response = client.execute(post);
                BufferedReader bufreader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "utf-8"));

                String line = null;
                String result = "";

                while ((line = bufreader.readLine()) != null) {
                    result += line;
                }

                return result;
            } catch (Exception e) {
                e.printStackTrace();
                client.getConnectionManager().shutdown(); // 연결 지연 종료
                return "";
            }
        }

        /*
         * 받은 JSON 객체를 파싱하는 메소드
         */
        private String jsonParserList(String pRecvServerPage) {
            Log.i("서버에서 받은 전체 내용 : ", pRecvServerPage);

            try {
                JSONObject json = new JSONObject(pRecvServerPage);

                // 받아온 pRecvServerPage를 분석하는 부분
                String jsonName = "msg";

                String result = json.getString(jsonName);

                // 분해 된 데이터를 확인하기 위한 부분
                Log.i("JSON을 분석한 데이터 : ", result);

                return result;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
    }
}
