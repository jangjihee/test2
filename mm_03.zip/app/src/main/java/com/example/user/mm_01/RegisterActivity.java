package com.example.user.mm_01;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class RegisterActivity extends AppCompatActivity {

    private EditText IdText;
    private EditText nameText;
    private EditText ageText;
    private EditText passwordText;
    private Button doneButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
                .detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());
        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        IdText = (EditText) findViewById(R.id.IdText);
        nameText = (EditText) findViewById(R.id.nameText);
        ageText = (EditText) findViewById(R.id.editText);
        passwordText = (EditText) findViewById(R.id.passwordText);
        doneButton = (Button) findViewById(R.id.doneButton);


        doneButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // 보내는 메시지를 받아옴
                String sMessage1 = IdText.getText().toString();
                String sMessage2 = nameText.getText().toString();
                String sMessage3 = ageText.getText().toString();
                String sMessage4 = passwordText.getText().toString();

                String sMessage;

                sMessage = sMessage1 + "/" + sMessage2 + "/" + sMessage3 + "/" + sMessage4;

                String result = SendByHttp(sMessage);

                String[][] parsedData = jsonParserList(result);

                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        });
    }
    private String SendByHttp(String msg) {
        if(msg == null )
            msg = "";

        String URL = "http://자신의 컴퓨터 IP:8080/" + "이 후 만들 WEBSERVER 파일명";

        DefaultHttpClient client = new DefaultHttpClient();

        try {

            HttpPost post = new HttpPost(URL + "?msg=" + msg);

            /* 지연시간 최대 5초 */
            HttpParams params = client.getParams();
            HttpConnectionParams.setConnectionTimeout(params, 3000);
            HttpConnectionParams.setSoTimeout(params, 3000);

            /* 데이터 보낸 뒤 서버에서 데이터를 받아오는 과정 */
            HttpResponse response = client.execute(post);
            BufferedReader bufreader = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent(),"utf-8"));

            String line = null;
            String result = "";

            while ((line = bufreader.readLine()) != null) {
                result += line;
            }

            return result;
        } catch (Exception e) {
            e.printStackTrace();
            client.getConnectionManager().shutdown(); // 연결 지연 종료
            return "";
        }
    }

    private String[][] jsonParserList(String pRecvServerPage) {
        Log.i("서버에서 받은 전체 내용 : ", pRecvServerPage);

        try {
            JSONObject json = new JSONObject(pRecvServerPage);
            JSONArray jArr = json.getJSONArray("List");

            // 받아온 pRecvServerPage를 분석하는 부분
            String[] jsonName = {"msg1", "msg2","msg3","msg4"};
            String[][] parseredData = new String[jArr.length()][jsonName.length];

            for (int i = 0; i < jArr.length(); i++) {
                json = jArr.getJSONObject(i);

                for (int j = 0; j < jsonName.length; j++) {
                    parseredData[i][j] = json.getString(jsonName[j]);
                }
            }

            // 분해 된 데이터를 확인하기 위한 부분
            for (int i = 0; i<parseredData.length; i++) {
                Log.i("ID " + i + " : ", parseredData[i][0]);
                Log.i("이름 " + i + " : ", parseredData[i][1]);
                Log.i("나이 " + i + " : ", parseredData[i][2]);
                Log.i("비밀번호 " + i + " : ", parseredData[i][3        ]);

            }
            return parseredData;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }
}




