package com.example.user.mm_01;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

public class SettingActivity extends AppCompatActivity {
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorite_activity);

        Intent intent = new Intent(this.getIntent());

        final EditText ReviewText2 = (EditText) findViewById(R.id.reviewText2);
        Button sendButton = (Button) findViewById(R.id.sendButton);

        sendButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                String name = ReviewText2.getText().toString();
                Intent intent = new Intent(getApplicationContext(), SendActivity.class);
                intent.putExtra("reviewText2", name);
                startActivity(intent);
            }
        });

        final TextView textView = (TextView)findViewById(R.id.rateText);
        RatingBar ratingBar = (RatingBar)findViewById(R.id.ratingBar);

        ratingBar.setOnRatingBarChangeListener(new  RatingBar.OnRatingBarChangeListener(){
            @Override
            public void  onRatingChanged(RatingBar ratingBar1, float rating, boolean fromUser){
                textView.setText("Rating : "+rating);
            }
        });

    }
}

